import medicalPrescription.Patient;
import medicalPrescription.PatientBuilder;
import medicalPrescription.Prescription;
import medicalPrescription.PrescriptionValidator;
import medicalPrescription.validationRules.*;

import java.util.Arrays;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        Prescription prescription = new Prescription("RX123", Arrays.asList("MedA", "MedB"));

        // Utilisation du PatientBuilder
        Patient patient = Patient.builder()
                .withId("P001")
                .withMedicalCondition("stable")
                .withWhiteBloodCellCount(300) // Ajout du taux de globules blancs
                .inGammaProtocol(true) // Patient dans le protocole Gamma
                .withRelapseAfter2019(false) // Pas de rechute après 2019
                .build();

        List<ValidationRule> rules = Arrays.asList(
                new PatientStateValidationRule(),
                new DrugInteractionValidationRule(),
                new ClinicalProtocolValidationRule(),
                new SupplyConstraintValidationRule()
        );

        PrescriptionValidator validator = new PrescriptionValidator(rules);
        validator.validate(prescription, patient);
    }
}
