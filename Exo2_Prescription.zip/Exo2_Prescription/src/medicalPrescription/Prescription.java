package medicalPrescription;

import java.util.List;

public class Prescription {
    private String id;
    private List<String> medications;

    public Prescription(String id, List<String> medications) {
        this.id = id;
        this.medications = medications;
    }

    public String getId() {
        return id;
    }

    public List<String> getMedications() {
        return medications;
    }

    public boolean containsMedication(String medication) {
        return medications.contains(medication);
    }

    public boolean containsMedications(String med1, String med2) {
        return medications.contains(med1) && medications.contains(med2);
    }
}

