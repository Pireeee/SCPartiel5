package medicalPrescription;

public class PatientBuilder {
    private String id;
    private String medicalCondition;
    private int whiteBloodCellCount;
    private boolean isInGammaProtocol;
    private boolean relapseAfter2019;
    private boolean hasGeneticMarkerBRCA1;
    private boolean isUnderMRIOnWednesday;

    public PatientBuilder withId(String id) {
        this.id = id;
        return this;
    }

    public PatientBuilder withMedicalCondition(String medicalCondition) {
        this.medicalCondition = medicalCondition;
        return this;
    }

    public PatientBuilder withWhiteBloodCellCount(int count) {
        this.whiteBloodCellCount = count;
        return this;
    }

    public PatientBuilder inGammaProtocol(boolean isInGammaProtocol) {
        this.isInGammaProtocol = isInGammaProtocol;
        return this;
    }

    public PatientBuilder withRelapseAfter2019(boolean relapseAfter2019) {
        this.relapseAfter2019 = relapseAfter2019;
        return this;
    }

    public PatientBuilder hasGeneticMarkerBRCA1(boolean hasGeneticMarkerBRCA1) {
        this.hasGeneticMarkerBRCA1 = hasGeneticMarkerBRCA1;
        return this;
    }

    public PatientBuilder underMRIOnWednesday(boolean isUnderMRIOnWednesday) {
        this.isUnderMRIOnWednesday = isUnderMRIOnWednesday;
        return this;
    }

    public Patient build() {
        return new Patient(id, medicalCondition, whiteBloodCellCount, isInGammaProtocol, relapseAfter2019, hasGeneticMarkerBRCA1, isUnderMRIOnWednesday);
    }
}
