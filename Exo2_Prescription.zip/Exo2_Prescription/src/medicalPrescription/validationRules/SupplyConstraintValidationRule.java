package medicalPrescription.validationRules;

import medicalPrescription.Patient;
import medicalPrescription.Prescription;
import medicalPrescription.ValidationResult;

public class SupplyConstraintValidationRule implements ValidationRule {
    @Override
    public ValidationResult validate(Prescription prescription, Patient patient) {
        // Simulation de contrainte d'approvisionnement
        if (prescription.getMedications().contains("RareMed")) {
            return new ValidationResult(false, "Le médicament RareMed est en rupture de stock.");
        }
        return new ValidationResult(true, "Médicaments disponibles.");
    }
}