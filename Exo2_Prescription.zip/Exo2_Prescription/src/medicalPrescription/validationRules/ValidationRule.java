package medicalPrescription.validationRules;

import medicalPrescription.Patient;
import medicalPrescription.Prescription;
import medicalPrescription.ValidationResult;

public interface ValidationRule {
    ValidationResult validate(Prescription prescription, Patient patient);
}
