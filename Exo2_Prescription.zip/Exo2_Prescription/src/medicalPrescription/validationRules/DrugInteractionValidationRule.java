package medicalPrescription.validationRules;

import medicalPrescription.Patient;
import medicalPrescription.Prescription;
import medicalPrescription.ValidationResult;

public class DrugInteractionValidationRule implements ValidationRule {
    private static final String MEDICATION_Y = "MedY";
    private static final String MEDICATION_Z = "MedZ";
    @Override
    public ValidationResult validate(Prescription prescription, Patient patient) {
        if (prescription.containsMedications(MEDICATION_Y, MEDICATION_Z)) {
            if (patient.hasGeneticMarkerBRCA1()) {
                return new ValidationResult(true, "Règle 327 : Le patient possède le marqueur BRCA1, combinaison autorisée.");
            }

            if (patient.isUnderMRIOnWednesday()) {
                return new ValidationResult(true, "Règle 327 : Le traitement est administré un mercredi sous IRM, combinaison autorisée.");
            }

            return new ValidationResult(false, "Règle 327 : Les médicaments Y et Z ne peuvent pas être combinés sans le marqueur BRCA1 ou une surveillance IRM un mercredi.");
        }

        return new ValidationResult(true, "Aucune interaction interdite détectée.");
    }
}
