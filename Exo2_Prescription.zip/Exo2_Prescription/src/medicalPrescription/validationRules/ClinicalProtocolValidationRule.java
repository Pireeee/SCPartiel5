package medicalPrescription.validationRules;

import medicalPrescription.Patient;
import medicalPrescription.Prescription;
import medicalPrescription.ValidationResult;

public class ClinicalProtocolValidationRule implements ValidationRule {
    @Override
    public ValidationResult validate(Prescription prescription, Patient patient) {
        return new ValidationResult(true, "La prescription respecte les protocoles de recherche clinique.");
    }
}
