package medicalPrescription.validationRules;
import medicalPrescription.Patient;
import medicalPrescription.Prescription;
import medicalPrescription.ValidationResult;

public class PatientStateValidationRule implements ValidationRule {
    private static final String MEDICATION_X = "MedX"; // Nom du médicament concerné

    @Override
    public ValidationResult validate(Prescription prescription, Patient patient) {
        // Si la prescription ne contient pas MedX, pas besoin de vérifier cette règle
        if (!prescription.containsMedication(MEDICATION_X)) {
            return new ValidationResult(true, "Validation état patient réussie.");
        }

        int wbcCount = patient.getWhiteBloodCellCount();

        // Si le patient est en rechute après 2019, aucune restriction
        if (patient.hasRelapseAfter2019()) {
            return new ValidationResult(true, "Règle 808 : Patient en rechute après 2019, pas de restriction sur MedX.");
        }

        // Si le patient est dans le protocole Gamma, son seuil est 1500
        if (patient.isInGammaProtocol() && wbcCount < 1500) {
            return new ValidationResult(false, "Règle 808 : Le patient est dans le protocole Gamma mais son taux de globules blancs est trop bas (< 1500/mm^3).");
        }

        // Sinon, le seuil normal est 2000
        if (!patient.isInGammaProtocol() && wbcCount < 2000) {
            return new ValidationResult(false, "Règle 808 : Le taux de globules blancs est trop bas pour recevoir MedX (< 2000/mm^3).");
        }

        return new ValidationResult(true, "Validation état patient réussie.");
    }
}

