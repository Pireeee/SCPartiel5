package medicalPrescription;

import medicalPrescription.validationRules.ValidationRule;
import java.util.List;

public class PrescriptionValidator {
    private List<ValidationRule> rules;

    public PrescriptionValidator(List<ValidationRule> rules) {
        this.rules = rules;
    }

    public void validate(Prescription prescription, Patient patient) {
        for (ValidationRule rule : rules) {
            ValidationResult result = rule.validate(prescription, patient);
            System.out.println(result.getMessage());
            if (!result.isValid()) {
                System.out.println("Prescription invalide.");
                return;
            }
        }
        System.out.println("Prescription validée avec succès.");
    }
}
