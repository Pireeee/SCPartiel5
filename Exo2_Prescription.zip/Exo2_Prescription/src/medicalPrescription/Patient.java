package medicalPrescription;

public class Patient {
    private String id;
    private String medicalCondition;
    private int whiteBloodCellCount;
    private boolean isInGammaProtocol;
    private boolean relapseAfter2019;
    private boolean hasGeneticMarkerBRCA1;
    private boolean isUnderMRIOnWednesday;

    Patient(String id, String medicalCondition, int whiteBloodCellCount, boolean isInGammaProtocol, boolean relapseAfter2019, boolean hasGeneticMarkerBRCA1, boolean isUnderMRIOnWednesday) {
        this.id = id;
        this.medicalCondition = medicalCondition;
        this.whiteBloodCellCount = whiteBloodCellCount;
        this.isInGammaProtocol = isInGammaProtocol;
        this.relapseAfter2019 = relapseAfter2019;
        this.hasGeneticMarkerBRCA1 = hasGeneticMarkerBRCA1;
        this.isUnderMRIOnWednesday = isUnderMRIOnWednesday;
    }

    public static PatientBuilder builder() {
        return new PatientBuilder();
    }

    public String getId() {
        return id;
    }

    public String getMedicalCondition() {
        return medicalCondition;
    }

    public int getWhiteBloodCellCount() {
        return whiteBloodCellCount;
    }

    public boolean isInGammaProtocol() {
        return isInGammaProtocol;
    }

    public boolean hasRelapseAfter2019() {
        return relapseAfter2019;
    }

    public boolean hasGeneticMarkerBRCA1() {
        return hasGeneticMarkerBRCA1;
    }

    public boolean isUnderMRIOnWednesday() {
        return isUnderMRIOnWednesday;
    }
}


